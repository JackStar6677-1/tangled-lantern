package com.tangledlantern.client;

import net.minecraft.class_2960;
import net.minecraft.class_5601;

public class ModModelLayers {
    public static final class_5601 FLOATING_LANTERN =
        new class_5601(class_2960.method_60655("tangledlantern", "floating_lantern"), "main");
}
