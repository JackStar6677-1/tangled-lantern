package com.tangledlantern.client.entity;

import com.tangledlantern.client.ModModelLayers;
import com.tangledlantern.entity.FloatingLanternEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.client.render.*;

public class FloatingLanternEntityRenderer extends class_897<FloatingLanternEntity> {
    private static final class_2960 TEXTURE =
        class_2960.method_60655("tangledlantern", "textures/entity/floating_lantern.png");

    private final FloatingLanternEntityModel<FloatingLanternEntity> model;

    public FloatingLanternEntityRenderer(class_5617.class_5618 ctx) {
        super(ctx);
        this.model = new FloatingLanternEntityModel<>(ctx.method_32167(ModModelLayers.FLOATING_LANTERN));
    }

    @Override
    public class_2960 getTexture(FloatingLanternEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(FloatingLanternEntity entity, float yaw, float tickDelta,
                       class_4587 matrices, class_4597 vertexConsumers, int light) {
        matrices.method_22903();

        float scale = 0.55f;
        // Flip Y and Z so the model faces correctly in world space
        matrices.method_22905(scale, -scale, -scale);

        // Slow rotation around Y axis
        float rotation = (entity.field_6012 + tickDelta) * 0.6f;
        matrices.method_22907(class_7833.field_40716.rotationDegrees(rotation));

        model.setAngles(entity, 0, 0, entity.field_6012 + tickDelta, 0, 0);

        // Render fully bright (emissive) so the lantern glows regardless of ambient light
        class_4588 vertexConsumer = vertexConsumers.getBuffer(
            class_1921.method_23578(TEXTURE)
        );
        model.method_60879(matrices, vertexConsumer,
            class_765.field_32767, class_4608.field_21444);

        matrices.method_22909();
        super.method_3936(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
