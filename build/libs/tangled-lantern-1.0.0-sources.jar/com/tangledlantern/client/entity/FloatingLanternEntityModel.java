package com.tangledlantern.client.entity;

import com.tangledlantern.entity.FloatingLanternEntity;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class FloatingLanternEntityModel<T extends FloatingLanternEntity> extends class_5597<T> {
    private final class_630 root;
    private final class_630 lantern;

    public FloatingLanternEntityModel(class_630 root) {
        this.root = root;
        this.lantern = root.method_32086("lantern");
    }

    /*
     * UV layout for lantern box (10w x 16h x 10d) starting at UV(0,0):
     *   TOP:   (10, 0)→(20,10)   BOT: (20, 0)→(30,10)
     *   WEST:  ( 0,10)→(10,26)   NORTH:(10,10)→(20,26)
     *   EAST:  (20,10)→(30,26)   SOUTH:(30,10)→(40,26)
     * Texture size: 64x64
     */
    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 root = modelData.method_32111();
        root.method_32117("lantern",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-5, -8, -5, 10, 16, 10),
            class_5603.field_27701);
        return class_5607.method_32110(modelData, 64, 64);
    }

    @Override
    public class_630 method_32008() {
        return root;
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        // Slow gentle sway
        lantern.field_3656 = (float) Math.sin(animationProgress * 0.05f) * 1.5f;
    }
}
