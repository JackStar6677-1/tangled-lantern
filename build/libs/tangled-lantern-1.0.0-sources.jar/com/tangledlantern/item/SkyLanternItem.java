package com.tangledlantern.item;

import com.tangledlantern.entity.FloatingLanternEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;

public class SkyLanternItem extends class_1792 {
    public SkyLanternItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!world.field_9236) {
            FloatingLanternEntity lantern = FloatingLanternEntity.create(world);
            class_243 look = user.method_5720();
            double spawnX = user.method_23317() + look.field_1352 * 1.2;
            double spawnY = user.method_23320();
            double spawnZ = user.method_23321() + look.field_1350 * 1.2;
            lantern.method_5814(spawnX, spawnY, spawnZ);
            world.method_8649(lantern);

            world.method_8396(null, user.method_24515(),
                class_3417.field_15013, class_3419.field_15248, 0.4f, 1.3f);
        }

        user.method_7259(class_3468.field_15372.method_14956(this));
        if (!user.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1271.method_29237(stack, world.method_8608());
    }
}
