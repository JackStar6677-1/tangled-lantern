package com.tangledlantern.entity;

import com.tangledlantern.registry.ModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;

public class FloatingLanternEntity extends class_1297 {
    // 5 minutes at 20 TPS
    private static final int MAX_LIFETIME = 6000;

    public FloatingLanternEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        this.field_5960 = true;
        this.method_5875(true);
    }

    public static FloatingLanternEntity create(class_1937 world) {
        return new FloatingLanternEntity(ModEntities.FLOATING_LANTERN, world);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.field_6012 >= MAX_LIFETIME) {
            this.method_31472();
            return;
        }

        // Slow upward float with gentle side drift
        double upSpeed = 0.035;
        double driftX = Math.sin(this.field_6012 * 0.04) * 0.007;
        double driftZ = Math.cos(this.field_6012 * 0.03) * 0.007;

        this.method_18799(new class_243(driftX, upSpeed, driftZ));
        this.method_5784(class_1313.field_6308, this.method_18798());

        // Small flame particles visible on client
        if (this.method_37908().field_9236 && this.field_6012 % 3 == 0) {
            this.method_37908().method_8406(
                class_2398.field_27783,
                this.method_23317() + (this.field_5974.method_43058() - 0.5) * 0.25,
                this.method_23318() + 0.05,
                this.method_23321() + (this.field_5974.method_43058() - 0.5) * 0.25,
                0, 0.008, 0
            );
        }
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {}

    @Override
    protected void method_5749(class_2487 nbt) {}

    @Override
    protected void method_5652(class_2487 nbt) {}

    @Override
    public boolean method_5732() {
        return false;
    }

    @Override
    public boolean method_30948() {
        return false;
    }
}
