package com.tangledlantern.registry;

import com.tangledlantern.TangledLantern;
import com.tangledlantern.item.SkyLanternItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModItems {
    public static final class_1792 SKY_LANTERN = class_2378.method_10230(
        class_7923.field_41178,
        class_2960.method_60655(TangledLantern.MOD_ID, "sky_lantern"),
        new SkyLanternItem(new class_1792.class_1793().method_7889(16))
    );

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> content.method_45421(SKY_LANTERN));
    }
}
