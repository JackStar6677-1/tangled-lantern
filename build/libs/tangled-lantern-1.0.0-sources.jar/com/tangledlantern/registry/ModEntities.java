package com.tangledlantern.registry;

import com.tangledlantern.TangledLantern;
import com.tangledlantern.entity.FloatingLanternEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEntities {
    public static final class_1299<FloatingLanternEntity> FLOATING_LANTERN = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655(TangledLantern.MOD_ID, "floating_lantern"),
        class_1299.class_1300.<FloatingLanternEntity>method_5903(FloatingLanternEntity::new, class_1311.field_17715)
            .method_17687(0.6f, 0.9f)
            .method_27299(8)
            .method_27300(3)
            .build()
    );

    public static void register() {}
}
